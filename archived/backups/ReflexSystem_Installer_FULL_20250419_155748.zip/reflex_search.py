
# reflex_search.py
# ระบบค้นหา memory capsule ตาม tag หรือวันที่ (Reflex Type-3 Compatible)

import os
import sys

def search_capsule(folder_path, keyword):
    results = []
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith(".txt"):
                full_path = os.path.join(root, file)
                with open(full_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    if keyword.lower() in content.lower():
                        results.append(full_path)
    return results

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("🛠️ วิธีใช้: python reflex_search.py [path] [keyword]")
        sys.exit(1)
    path = sys.argv[1]
    keyword = sys.argv[2]
    matches = search_capsule(path, keyword)
    if matches:
        print("🔍 พบไฟล์ที่ตรงกับคำค้น:")
        for match in matches:
            print(" -", match)
    else:
        print("❌ ไม่พบผลลัพธ์ที่ตรงกับคำค้น")
