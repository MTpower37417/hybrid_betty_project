
# reflex_readme_generator.py
# สร้าง README.txt สำหรับ Reflex Capsule System (Auto-generated Instruction)

readme_content = """===========================
📦 Reflex Capsule System
===========================

This system includes two independent Reflex memory environments:

1. Bedroom_Betty/
2. Office_Room/

Each capsule supports:
- Emotional tracking
- Summary, reporting, and plotting
- Backup and restore
- Full Reflex automation with .sh scripts

---------------------------
📁 Structure Overview:
---------------------------
- emotional_tracker.py       → Log new emotional events
- reflex_summary.py          → Text-based summary of memory logs
- reflex_report.py           → Export to emotion_report.csv
- reflex_plot.py             → Generate emotion_plot.png
- reflex_backup.py           → Create ZIP backups in /backups
- reflex_restore.py          → Restore system from backup
- reflex_auto_backup.sh      → One-click backup automation
- reflex_auto_restore.sh     → Restore most recent backup
- reflex_build_package.py    → Create deployable .zip installer
- reflex_deploy_all.sh       → Setup both Betty & Office rooms
- reflex_office_bootstrap.sh → Bootstrap Office_Room only

---------------------------
🚀 How to Start:
---------------------------
1. Run:    bash reflex_deploy_all.sh
2. Track:  python emotional_tracker.py sad "Example note"
3. Report: python reflex_report.py
4. Plot:   python reflex_plot.py
5. Backup: bash reflex_auto_backup.sh
6. Restore: bash reflex_auto_restore.sh

Happy Logging!
"""

with open("README.txt", "w", encoding="utf-8") as f:
    f.write(readme_content)

print("✅ README.txt has been generated.")
