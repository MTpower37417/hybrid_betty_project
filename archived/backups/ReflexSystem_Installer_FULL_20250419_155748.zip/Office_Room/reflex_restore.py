
# reflex_restore.py
# Restore backup ZIP capsule กลับเข้าสู่ระบบ Reflex (Reflex Type-3)

import os
import sys
from zipfile import ZipFile

def restore_backup(zip_path):
    if not os.path.exists(zip_path):
        print(f"❌ ไม่พบไฟล์ backup: {zip_path}")
        return
    with ZipFile(zip_path, 'r') as zipf:
        zipf.extractall(".")
    print(f"✅ กู้คืนข้อมูลเรียบร้อยแล้วจาก: {zip_path}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("🛠️ วิธีใช้: python reflex_restore.py [backup.zip]")
        sys.exit(1)
    restore_backup(sys.argv[1])
