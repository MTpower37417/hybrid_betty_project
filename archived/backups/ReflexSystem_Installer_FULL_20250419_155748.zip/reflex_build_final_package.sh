
#!/bin/bash
# reflex_build_final_package.sh
# รวมระบบทั้งหมด + README.txt เข้า Reflex Installer ZIP

cd ~/Documents/ReflexSystem

echo "📦 สร้าง Reflex Installer (with README)..."

# 1. สร้าง README ถ้ายังไม่มี
if [ ! -f README.txt ]; then
    echo "⚠️ ไม่พบ README.txt — สร้างใหม่..."
    python reflex_readme_generator.py
fi

# 2. สร้างชื่อไฟล์ ZIP
ZIP_NAME="ReflexSystem_Installer_FULL_$(date +%Y%m%d_%H%M%S).zip"

# 3. สร้าง ZIP พร้อมทุกไฟล์ + README
python reflex_build_package.py

# 4. ค้นหา ZIP ล่าสุดที่สร้าง (โดย Python build)
LATEST_ZIP=$(ls -t ReflexSystem_Installer_*.zip | head -n 1)

# 5. เปลี่ยนชื่อเป็น FINAL
mv "$LATEST_ZIP" "$ZIP_NAME"

echo "✅ เสร็จสมบูรณ์: $ZIP_NAME"
