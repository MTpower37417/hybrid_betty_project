import os
import argparse

room_paths = {
    "office": "Office_Room/cache",
    "betty": "Bedroom_Betty/cache"
}

def merge_capsules(folder, output_file):
    files = sorted([f for f in os.listdir(folder) if f.endswith(".txt")],
                   key=lambda x: os.path.getmtime(os.path.join(folder, x)))

    with open(output_file, "w", encoding="utf-8") as out_f:
        for f in files:
            path = os.path.join(folder, f)
            with open(path, "r", encoding="utf-8") as in_f:
                out_f.write(f"===== {f} =====\n")
                out_f.write(in_f.read())
                out_f.write("\n\n")

    print(f"✅ Merged {len(files)} capsules → {output_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Merge Reflex Capsules to One Timeline")
    parser.add_argument('--room', type=str, required=True, choices=["office", "betty"], help="เลือกห้อง (office / betty)")
    parser.add_argument('--output', type=str, required=False, help="ชื่อไฟล์ output", default="merged_capsules.txt")
    args = parser.parse_args()

    folder = os.path.join(os.path.dirname(__file__), room_paths[args.room])
    output_path = os.path.join(os.path.dirname(__file__), args.output)
    merge_capsules(folder, output_path)