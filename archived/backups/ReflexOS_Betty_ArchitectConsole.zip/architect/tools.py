# Architect tools logic
