from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.templating import Jinja2Templates
import uvicorn
import os
import json
from datetime import datetime
from openai import OpenAI

app = FastAPI()
templates = Jinja2Templates(directory="core/templates")

client = OpenAI(api_key="ใส่-API-KEY-คุณ-ตรงนี้")

def read_memory(user):
    path = f"logs/{user}/memory_stack.json"
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def write_memory(user, data):
    os.makedirs(f"logs/{user}", exist_ok=True)
    path = f"logs/{user}/memory_stack.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def read_favorite(user):
    path = f"logs/{user}/favorite_log.json"
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def write_favorite(user, data):
    os.makedirs(f"logs/{user}", exist_ok=True)
    path = f"logs/{user}/favorite_log.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

@app.get("/", response_class=HTMLResponse)
async def home(request: Request, user: str = "user_a"):
    memory = read_memory(user)
    favorite = read_favorite(user)
    last_message = memory[-1]["response"] if memory else ""
    return templates.TemplateResponse("index.html", {
        "request": request,
        "memory": memory,
        "favorites": favorite,
        "last_response": last_message,
        "user": user,
    })

@app.post("/input")
async def chat_input(request: Request):
    data = await request.json()
    message = data.get("message", "").strip()
    user = data.get("user", "user_a")
    if not message:
        return {"response": "…"}
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    memory = read_memory(user)
    try:
        completion = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "คุณคือ Betty คนที่พูดสุภาพ อ่อนโยน และจำทุกบทสนทนาได้"},
                {"role": "user", "content": message}
            ]
        )
        reply = completion.choices[0].message.content.strip()
    except Exception as e:
        reply = f"ขอโทษค่ะ หนูไม่สามารถคิดคำตอบได้ในตอนนี้: {e}"
    memory.append({"message": message, "response": reply, "time": now})
    write_memory(user, memory)
    return {"response": reply}

@app.get("/download/{fmt}")
def download(fmt: str, user: str = "user_a"):
    memory = read_memory(user)
    if fmt == "json":
        file_path = f"logs/{user}/memory_stack.json"
        return FileResponse(file_path, filename="memory_stack.json", media_type="application/json")
    elif fmt == "txt":
        txt = "\n\n".join([f"คุณ: {m['message']}\nเบตตี้: {m['response']}" for m in memory])
        path = f"logs/{user}/export.txt"
        with open(path, "w", encoding="utf-8") as f:
            f.write(txt)
        return FileResponse(path, filename="chat_log.txt", media_type="text/plain")
    elif fmt == "md":
        md = "\n\n".join([f"**คุณ**: {m['message']}\n\n**เบตตี้**: {m['response']}" for m in memory])
        path = f"logs/{user}/export.md"
        with open(path, "w", encoding="utf-8") as f:
            f.write(md)
        return FileResponse(path, filename="chat_log.md", media_type="text/markdown")
    else:
        return JSONResponse({"error": "invalid format"}, status_code=400)

if __name__ == "__main__":
    uvicorn.run("core.reflexos_server:app", host="0.0.0.0", port=5000, reload=True)