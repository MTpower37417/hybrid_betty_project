
# reflex_summary.py
# สรุปความรู้สึกจาก emotional logs แบบรวบยอด (Reflex Type-3 Compatible)

import os
from collections import defaultdict
from datetime import datetime

LOG_DIR = "Bedroom_Betty/logs"

def summarize_emotions():
    summary = defaultdict(list)
    if not os.path.exists(LOG_DIR):
        print("❌ ไม่พบโฟลเดอร์ logs: Bedroom_Betty/logs")
        return

    for file in os.listdir(LOG_DIR):
        if file.startswith("emotion_") and file.endswith(".txt"):
            parts = file.replace(".txt", "").split("_")
            if len(parts) >= 3:
                emotion = parts[1]
                timestamp = "_".join(parts[2:])
                summary[emotion].append(timestamp)

    if not summary:
        print("ℹ️ ยังไม่มีอารมณ์ถูกบันทึก")
        return

    print("🧠 สรุปอารมณ์ Betty:")
    for emotion, times in summary.items():
        print(f" - {emotion.upper()} × {len(times)} ครั้ง")
        for t in times:
            print(f"   • {t.replace('_', ' ')}")

if __name__ == "__main__":
    summarize_emotions()
