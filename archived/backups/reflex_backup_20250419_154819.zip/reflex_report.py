
# reflex_report.py
# Export emotional summary report to CSV (Reflex Type-3 Compatible)

import os
import csv
from collections import defaultdict
from datetime import datetime

LOG_DIR = "Bedroom_Betty/logs"
OUTPUT_CSV = "Bedroom_Betty/emotion_report.csv"

def export_emotion_report():
    summary = defaultdict(list)
    if not os.path.exists(LOG_DIR):
        print("❌ ไม่พบโฟลเดอร์ logs: Bedroom_Betty/logs")
        return

    for file in os.listdir(LOG_DIR):
        if file.startswith("emotion_") and file.endswith(".txt"):
            parts = file.replace(".txt", "").split("_")
            if len(parts) >= 3:
                emotion = parts[1]
                timestamp = "_".join(parts[2:])
                readable_time = timestamp.replace("_", " ")
                summary[emotion].append(readable_time)

    if not summary:
        print("ℹ️ ยังไม่มีข้อมูลสำหรับ export")
        return

    os.makedirs("Bedroom_Betty", exist_ok=True)
    with open(OUTPUT_CSV, "w", encoding="utf-8", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["Emotion", "Timestamp"])
        for emotion, times in summary.items():
            for t in times:
                writer.writerow([emotion, t])

    print(f"✅ รายงานถูกสร้างแล้ว: {OUTPUT_CSV}")

if __name__ == "__main__":
    export_emotion_report()
