
#!/bin/bash
# reflex_build_package.sh
# สร้าง ZIP Installer สำหรับ Reflex Capsule System (Betty + Office)

cd ~/Documents/ReflexSystem

PACKAGE_NAME="ReflexSystem_Installer_$(date +%Y%m%d_%H%M%S).zip"

echo "📦 สร้างแพ็กเกจติดตั้ง: $PACKAGE_NAME"

zip -r $PACKAGE_NAME Bedroom_Betty Office_Room backups *.py *.sh > /dev/null

echo "✅ แพ็กเกจพร้อมใช้งาน: $PACKAGE_NAME"
