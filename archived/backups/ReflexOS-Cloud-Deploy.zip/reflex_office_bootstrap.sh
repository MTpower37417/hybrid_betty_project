
#!/bin/bash
# reflex_office_bootstrap.sh
# ติดตั้งระบบ Reflex Capsule สำหรับ Office_Room (Reflex Type-3 Compatible)

cd ~/Documents/ReflexSystem

echo "🏢 กำลังติดตั้ง Reflex Capsule ฝั่ง Office..."

# 1. สร้างโฟลเดอร์
mkdir -p Office_Room/logs

# 2. สร้างไฟล์ capsule ตัวอย่าง
echo "[START] Office Capsule Ready." > Office_Room/logs/office_start_$(date +"%Y-%m-%d_%H-%M-%S").txt

# 3. Copy สคริปต์หลักจากฝั่ง Betty มาใช้ได้ร่วมกัน
cp emotional_tracker.py Office_Room/emotional_tracker.py
cp reflex_summary.py Office_Room/reflex_summary.py
cp reflex_report.py Office_Room/reflex_report.py
cp reflex_plot.py Office_Room/reflex_plot.py
cp reflex_backup.py Office_Room/reflex_backup.py
cp reflex_restore.py Office_Room/reflex_restore.py

echo "✅ ระบบ Reflex Office_Room ติดตั้งเสร็จสมบูรณ์"
