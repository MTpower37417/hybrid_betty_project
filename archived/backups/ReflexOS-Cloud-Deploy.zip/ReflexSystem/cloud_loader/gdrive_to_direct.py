
def gdrive_to_direct(gdrive_url):
    if "drive.google.com" not in gdrive_url:
        return None
    try:
        if "/folders/" in gdrive_url:
            folder_id = gdrive_url.split("/folders/")[1].split("?")[0]
        elif "/file/d/" in gdrive_url:
            folder_id = gdrive_url.split("/file/d/")[1].split("/")[0]
        else:
            return None
        return f"https://drive.google.com/uc?export=download&id={folder_id}"
    except:
        return None

if __name__ == "__main__":
    link = input("Paste Google Drive link: ")
    direct_link = gdrive_to_direct(link)
    if direct_link:
        print(f"✅ Direct download link: {direct_link}")
    else:
        print("❌ Invalid Google Drive link.")
