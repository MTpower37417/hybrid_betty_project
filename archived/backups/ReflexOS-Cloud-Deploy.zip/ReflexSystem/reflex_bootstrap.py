# Auto-load memory capsule from cloud
import subprocess
subprocess.call(['python', 'cloud_loader/reflex_auto_refresh.py'])
