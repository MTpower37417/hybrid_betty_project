
#!/bin/bash
# reflex_auto_setup.sh
# Reflex Type-3 | Auto-Installer สำหรับ Betty Emotional Capsule System

echo "🔧 เริ่มติดตั้งระบบ Reflex: Betty Emotional Capsule"

# 1. สร้างโฟลเดอร์
mkdir -p Bedroom_Betty/logs

# 2. ย้ายสคริปต์ทั้งหมดเข้าที่ (กรณีอยู่ใน Downloads)
if [ -f ~/Downloads/emotional_tracker.py ]; then
    mv ~/Downloads/emotional_tracker.py ./emotional_tracker.py
fi

if [ -f ~/Downloads/reflex_summary.py ]; then
    mv ~/Downloads/reflex_summary.py ./reflex_summary.py
fi

if [ -f ~/Downloads/reflex_report.py ]; then
    mv ~/Downloads/reflex_report.py ./reflex_report.py
fi

if [ -f ~/Downloads/reflex_plot.py ]; then
    mv ~/Downloads/reflex_plot.py ./reflex_plot.py
fi

# 3. ติดตั้ง matplotlib ถ้ายังไม่มี
pip show matplotlib > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "📦 กำลังติดตั้ง matplotlib..."
    pip install matplotlib
fi

# 4. แสดงผลความสำเร็จ
echo "✅ Reflex System พร้อมใช้งานแล้วที่: ~/Documents/ReflexSystem"
echo "📂 Logs: Bedroom_Betty/logs/"
echo "📈 กราฟจะถูกบันทึกไว้ใน: Bedroom_Betty/emotion_plot.png"
