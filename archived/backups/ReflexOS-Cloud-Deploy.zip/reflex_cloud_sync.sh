"/c/Program Files/rclone/rclone.exe" copy backups reflex_drive:ReflexBackup --quiet
