
#!/bin/bash
# reflex_deploy_all.sh
# Reflex Type-3: Deploy ทั้งระบบ Betty + Office Capsule

cd ~/Documents/ReflexSystem

echo "🚀 เริ่มติดตั้งระบบ Reflex Capsule ครบชุด..."

# 1. สร้างโฟลเดอร์หลัก
mkdir -p Bedroom_Betty/logs
mkdir -p Office_Room/logs
mkdir -p backups

# 2. ย้ายไฟล์ .py หลัก
mv ~/Downloads/emotional_tracker.py ./emotional_tracker.py 2>/dev/null
mv ~/Downloads/reflex_summary.py ./reflex_summary.py 2>/dev/null
mv ~/Downloads/reflex_report.py ./reflex_report.py 2>/dev/null
mv ~/Downloads/reflex_plot.py ./reflex_plot.py 2>/dev/null
mv ~/Downloads/reflex_backup.py ./reflex_backup.py 2>/dev/null
mv ~/Downloads/reflex_restore.py ./reflex_restore.py 2>/dev/null

# 3. ติดตั้ง matplotlib ถ้ายังไม่มี
pip show matplotlib > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "📦 ติดตั้ง matplotlib..."
    pip install matplotlib
fi

# 4. คัดลอกสคริปต์จาก Betty ไป Office
cp emotional_tracker.py Office_Room/emotional_tracker.py
cp reflex_summary.py Office_Room/reflex_summary.py
cp reflex_report.py Office_Room/reflex_report.py
cp reflex_plot.py Office_Room/reflex_plot.py
cp reflex_backup.py Office_Room/reflex_backup.py
cp reflex_restore.py Office_Room/reflex_restore.py

# 5. สร้าง Capsule เริ่มต้น
echo "[START] Betty Capsule Initialized." > Bedroom_Betty/logs/betty_start_$(date +"%Y-%m-%d_%H-%M-%S").txt
echo "[START] Office Capsule Initialized." > Office_Room/logs/office_start_$(date +"%Y-%m-%d_%H-%M-%S").txt

echo "✅ Reflex Capsule System ทั้งหมดติดตั้งเสร็จสมบูรณ์"
