
# reflex_memory_search.py
# Reflex Memory Search Engine – ค้นหา Capsule ที่เกี่ยวข้องด้วยคำค้น

import os
import sys

LOG_FOLDER = "Bedroom_Betty/logs"

def search_capsules(keyword):
    results = []
    if not os.path.exists(LOG_FOLDER):
        return results
    for fname in os.listdir(LOG_FOLDER):
        if fname.endswith(".txt"):
            full_path = os.path.join(LOG_FOLDER, fname)
            with open(full_path, "r", encoding="utf-8") as f:
                content = f.read().lower()
                if keyword.lower() in content:
                    results.append((fname, full_path))
    return results

def display_results(results):
    if not results:
        print("❌ ไม่พบ capsule ที่เกี่ยวข้องกับคำค้นนี้")
        return
    print(f"🔍 พบทั้งหมด {len(results)} รายการที่เกี่ยวข้อง:\n")
    for fname, path in results:
        print(f"- {fname} → {path}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("📌 วิธีใช้: python reflex_memory_search.py <คำค้น>")
        sys.exit(0)

    keyword = sys.argv[1]
    matches = search_capsules(keyword)
    display_results(matches)
