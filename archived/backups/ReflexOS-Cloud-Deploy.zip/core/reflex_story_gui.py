
# reflex_story_gui.py
# เปิด Reflex Story Narrative ใน GUI Scrollable Reader

import tkinter as tk
from tkinter import scrolledtext
import os

FILE_PATH = "reflex_story_narrative.txt"

def open_gui():
    window = tk.Tk()
    window.title("📖 Reflex Story Viewer")
    window.geometry("800x600")

    tk.Label(window, text="🧠 Reflex AI Story Diary", font=("Helvetica", 16, "bold")).pack(pady=10)

    box = scrolledtext.ScrolledText(window, wrap=tk.WORD, font=("Helvetica", 12))
    box.pack(expand=True, fill='both', padx=20, pady=10)

    if os.path.exists(FILE_PATH):
        with open(FILE_PATH, "r", encoding="utf-8") as f:
            content = f.read()
            box.insert(tk.END, content)
    else:
        box.insert(tk.END, "❌ ไม่พบไฟล์ story narrative.\n\nโปรดรัน reflex_story_mode.py ก่อน")

    box.config(state='disabled')
    window.mainloop()

if __name__ == "__main__":
    open_gui()
