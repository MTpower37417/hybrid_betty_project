# reflex_plan_gui.py
# GUI Viewer แผน Reflex

import tkinter as tk

with open("reflex_plan_from_capsule.txt", encoding="utf-8") as f:
    plan = f.read()

root = tk.Tk()
root.title("📋 Reflex Plan Viewer")
text = tk.Text(root, font=("Consolas", 11), wrap="word", padx=10, pady=10)
text.insert(tk.END, plan)
text.pack(expand=True, fill='both')
root.mainloop()
