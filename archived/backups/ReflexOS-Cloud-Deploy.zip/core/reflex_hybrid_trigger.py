
# reflex_hybrid_trigger.py
# Reflex Hybrid Trigger System: Emotion-based + Event-based logging

import os
from datetime import datetime

BEDROOM_LOGS = "Bedroom_Betty/logs"

def write_capsule(tag, note, trigger_type="manual"):
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    os.makedirs(BEDROOM_LOGS, exist_ok=True)
    filename = f"{BEDROOM_LOGS}/capsule_{trigger_type}_{tag}_{timestamp}.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"[{timestamp}]\nTrigger: {trigger_type}\nTag: {tag}\nNote: {note}\n")
    print(f"✅ Capsule saved: {filename}")

def trigger_emotion(emotion, note):
    write_capsule(tag=emotion, note=note, trigger_type="emotion")

def trigger_event(event_name, note=""):
    write_capsule(tag=event_name, note=note, trigger_type="event")

if __name__ == "__main__":
    # ทดสอบตัวอย่าง 2 ประเภทการ trigger
    trigger_emotion("frustrated", "Boss sent 3000 files unexpectedly.")
    trigger_event("unzip_massive", "System handled 3000 file unzip without warning.")
