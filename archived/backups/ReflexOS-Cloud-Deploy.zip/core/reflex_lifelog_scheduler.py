
# reflex_lifelog_scheduler.py
# รัน reflex_lifelog_writer.py ซ้ำทุกช่วงเวลา (แบบ cron simulation)

import time
import subprocess
from datetime import datetime

INTERVAL_MINUTES = 60  # ทุกกี่นาทีจะสรุปอีกครั้ง (กำหนดได้)

def run_lifelog():
    while True:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"📅 [{timestamp}] สรุปไดอารี่ประจำรอบ...")
        subprocess.run("python reflex_lifelog_writer.py", shell=True)
        print("✅ บันทึกเสร็จแล้ว รอรอบถัดไป...\n")
        time.sleep(INTERVAL_MINUTES * 60)

if __name__ == "__main__":
    run_lifelog()
