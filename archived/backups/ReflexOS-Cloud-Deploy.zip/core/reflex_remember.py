import argparse
import os
from datetime import datetime

# Mapping สำหรับห้องต่าง ๆ
room_paths = {
    "office": "Office_Room/cache",
    "betty": "Bedroom_Betty/cache"
}

# รับ argument จาก command line
parser = argparse.ArgumentParser(description="Reflex Remember System")
parser.add_argument('--room', type=str, required=True, choices=["office", "betty"], help="เลือกห้องที่ต้องการบันทึก (office / betty)")
parser.add_argument('--text', type=str, required=True, help="ข้อความที่ต้องการบันทึก")
parser.add_argument('--tags', type=str, default="", help="แท็กเพิ่มเติม เช่น 'ทะเล,แฟน,โรแมนติก'")
args = parser.parse_args()

# สร้างชื่อไฟล์
now = datetime.now()
timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
filename = f"{args.room}_{timestamp}.txt"
folder_path = os.path.join(os.path.dirname(__file__), room_paths[args.room])
file_path = os.path.join(folder_path, filename)

# เขียนไฟล์
with open(file_path, "w", encoding="utf-8") as f:
    f.write("# Reflex Memory Capsule\n")
    f.write(f"Date: {now.strftime('%Y-%m-%d %H:%M:%S')}\n")
    f.write(f"Room: {args.room.title()}\n")
    f.write(f"Tags: {args.tags}\n\n")
    f.write(args.text.strip())

print(f"✅ Memory saved to: {file_path}")