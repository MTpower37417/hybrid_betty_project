import os
import argparse

# โฟลเดอร์เก็บ memory ตามห้อง
room_paths = {
    "office": "Office_Room/cache",
    "betty": "Bedroom_Betty/cache"
}

def search_files(folder, keyword):
    results = []
    for file in os.listdir(folder):
        if file.endswith(".txt"):
            path = os.path.join(folder, file)
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
                if keyword.lower() in content.lower():
                    results.append((file, content.splitlines()[0]))  # แสดงแค่หัวเรื่อง
    return results

parser = argparse.ArgumentParser(description="Reflex Recall System")
parser.add_argument('--room', type=str, required=True, choices=["office", "betty"], help="เลือกห้องที่ต้องการค้นหา (office / betty)")
parser.add_argument('--keyword', type=str, required=True, help="คำค้น เช่น 'ทะเล', 'token', 'project'")
args = parser.parse_args()

folder = os.path.join(os.path.dirname(__file__), room_paths[args.room])
matches = search_files(folder, args.keyword)

if matches:
    print(f"🔍 พบ {len(matches)} รายการ:")
    for fname, preview in matches:
        print(f"📄 {fname} → {preview}")
else:
    print("❌ ไม่พบความจำที่ตรงกับ keyword นี้.")