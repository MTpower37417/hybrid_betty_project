
# reflex_merge_timeline.py
# รวมความจำจาก Betty, Jarvis, Office เป็นไทม์ไลน์เดียว

import os
from datetime import datetime

LOG_DIRS = [
    "Bedroom_Betty/logs",
    "Jarvis_Lab/logs",
    "Office_Room/logs"
]

MERGED_FILE = "merged_capsule_timeline.txt"

def extract_timestamp(line):
    try:
        return datetime.strptime(line.strip()[1:20], "%Y-%m-%d_%H-%M-%S")
    except:
        return None

def collect_capsules():
    capsules = []
    for folder in LOG_DIRS:
        if not os.path.exists(folder):
            continue
        for fname in os.listdir(folder):
            if fname.startswith("capsule_") and fname.endswith(".txt"):
                fpath = os.path.join(folder, fname)
                with open(fpath, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                    ts = extract_timestamp(lines[0]) if lines else None
                    content = "".join(lines)
                    if ts:
                        capsules.append((ts, fpath, content))
    return sorted(capsules, key=lambda x: x[0])

def merge_capsules():
    capsules = collect_capsules()
    with open(MERGED_FILE, "w", encoding="utf-8") as out:
        for ts, path, content in capsules:
            out.write(f"📄 From: {path}\n{content}\n{'-'*60}\n")
    print(f"✅ รวมสำเร็จ: {MERGED_FILE} (ทั้งหมด {len(capsules)} capsules)")

if __name__ == "__main__":
    merge_capsules()
