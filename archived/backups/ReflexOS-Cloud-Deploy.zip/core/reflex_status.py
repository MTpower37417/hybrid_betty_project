import os

def count_capsules(folder):
    return len([f for f in os.listdir(folder) if f.endswith(".txt")])

def print_status(base_path):
    rooms = {
        "Office": {
            "cache": "Office_Room/cache",
            "archive": "Office_Room/archive"
        },
        "Betty": {
            "cache": "Bedroom_Betty/cache",
            "archive": "Bedroom_Betty/archive"
        }
    }

    print("🧠 Reflex Memory Status")
    print("-" * 30)
    for room, paths in rooms.items():
        cache_path = os.path.join(base_path, paths["cache"])
        archive_path = os.path.join(base_path, paths["archive"])
        cache_count = count_capsules(cache_path)
        archive_count = count_capsules(archive_path)
        print(f"📁 {room} Room")
        print(f"   🧳 Cache:   {cache_count} capsule(s)")
        print(f"   📦 Archive: {archive_count} capsule(s)")
        print()

if __name__ == "__main__":
    base_dir = os.path.dirname(__file__)
    print_status(base_dir)