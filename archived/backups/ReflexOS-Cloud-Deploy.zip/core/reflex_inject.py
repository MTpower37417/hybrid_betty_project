import os
from datetime import datetime

def inject_chat_to_capsule(room, text, tag="auto-inject", base_dir=None):
    room_paths = {
        "office": "Office_Room/cache",
        "betty": "Bedroom_Betty/cache"
    }

    if room not in room_paths:
        raise ValueError("Room ต้องเป็น 'office' หรือ 'betty'")

    now = datetime.now()
    timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"{room}_{timestamp}.txt"

    if not base_dir:
        base_dir = os.path.dirname(__file__)
    folder_path = os.path.join(base_dir, room_paths[room])
    os.makedirs(folder_path, exist_ok=True)

    file_path = os.path.join(folder_path, filename)

    try:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("# Reflex Injected Capsule\n")
            f.write(f"Date: {now.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Room: {room.title()}\n")
            f.write(f"Tags: {tag}\n\n")
            f.write(text.strip())

        print(f"✅ Injected chat capsule to: {file_path}")
    except Exception as e:
        print(f"❌ Error writing capsule: {e}")

    return file_path