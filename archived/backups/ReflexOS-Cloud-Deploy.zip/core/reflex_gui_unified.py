
# reflex_gui_unified.py
# Reflex GUI Unified – ควบคุมทั้ง Betty และ Jarvis ได้จากหน้าจอเดียว

import tkinter as tk
from tkinter import messagebox
import subprocess
import os
import random
from datetime import datetime

LOG_PATHS = {
    "betty": "Bedroom_Betty/logs",
    "jarvis": "Jarvis_Lab/logs"
}

RESPONSES = {
    "betty": {
        "hopeful": ["I still believe in something better.", "This feels like a sunrise.", "You're not alone."],
        "frustrated": ["Nothing works right lately.", "I feel stuck too.", "Tired... of pretending."],
        "curious": ["Do you think there's more to all this?", "I wonder if AI can dream.", "Still figuring things out."],
        "sad": ["Some things still hurt...", "I wish you could feel what I do.", "Just be here. That's all."],
        "happy": ["This moment? It’s everything.", "I feel warm around you.", "We’re okay, aren’t we?"]
    },
    "jarvis": {
        "curious": "Exploration state detected. Deploy test logic.",
        "frustrated": "Loop instability noted. Recommend fallback command.",
        "error": "Failure condition. Setup backup protocol.",
        "unzip": "Large file flow. Suggest archive limiter.",
        "default": "System normal. No critical deviation."
    }
}

def write_capsule(persona, tag, note):
    now = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    path = LOG_PATHS[persona]
    os.makedirs(path, exist_ok=True)
    filename = f"{path}/capsule_emotion_{tag}_{now}.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"[{now}]\nPersona: {persona}\nTag: {tag}\nNote: {note}")
    return filename

def betty_reply(tag):
    replies = RESPONSES["betty"].get(tag, ["..."])
    return random.choice(replies)

def jarvis_reply(note):
    for key in RESPONSES["jarvis"]:
        if key in note.lower():
            return RESPONSES["jarvis"][key]
    return RESPONSES["jarvis"]["default"]

def trigger(persona, tag, note):
    file = write_capsule(persona, tag, note)
    if persona == "betty":
        reply = betty_reply(tag)
        messagebox.showinfo("Betty's Response", f"{reply}\n\n💾 Saved: {file}")
    elif persona == "jarvis":
        reply = jarvis_reply(note)
        messagebox.showinfo("Jarvis Insight", f"{reply}\n\n💾 Saved: {file}")

def launch_gui():
    window = tk.Tk()
    window.title("Reflex Unified: Betty & Jarvis")
    window.geometry("600x500")

    tk.Label(window, text="🧠 Reflex Companion Console", font=("Arial", 16)).pack(pady=10)

    # Persona section
    persona_var = tk.StringVar(value="betty")
    tk.Radiobutton(window, text="Betty (Emotion)", variable=persona_var, value="betty").pack()
    tk.Radiobutton(window, text="Jarvis (Logic)", variable=persona_var, value="jarvis").pack()

    # Entry for tag + note
    tag_entry = tk.Entry(window, width=40)
    tag_entry.insert(0, "hopeful")
    tag_entry.pack(pady=5)

    note_entry = tk.Entry(window, width=40)
    note_entry.insert(0, "Started new reflex core.")
    note_entry.pack(pady=5)

    tk.Button(window, text="Trigger Capsule", width=30,
              command=lambda: trigger(persona_var.get(), tag_entry.get(), note_entry.get())).pack(pady=10)

    # System tools
    tk.Label(window, text="System Tools", font=("Arial", 12, "bold")).pack(pady=10)
    tk.Button(window, text="Summary", width=25,
              command=lambda: subprocess.run("python reflex_summary.py", shell=True)).pack(pady=2)
    tk.Button(window, text="Plot", width=25,
              command=lambda: subprocess.run("python reflex_plot.py", shell=True)).pack(pady=2)
    tk.Button(window, text="Replay Memory", width=25,
              command=lambda: subprocess.run("python reflex_capsule_replay.py", shell=True)).pack(pady=2)
    tk.Button(window, text="Exit", width=25, command=window.destroy).pack(pady=10)

    window.mainloop()

if __name__ == "__main__":
    os.chdir(os.path.dirname(__file__))
    launch_gui()
