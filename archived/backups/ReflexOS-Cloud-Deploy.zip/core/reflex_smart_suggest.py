
# reflex_smart_suggest.py
# แนะนำ capsule ที่ควรนำกลับมาใช้ จาก tag ที่เกิดบ่อยในรอบล่าสุด

import os
from collections import Counter
from datetime import datetime, timedelta

LOG_DIR = "Office_Room/logs"
DAYS_BACK = 5  # ดูย้อนหลังไม่เกินกี่วัน

def recent_capsules():
    recent = []
    now = datetime.now()
    for fname in os.listdir(LOG_DIR):
        if fname.startswith("capsule_") and fname.endswith(".txt"):
            path = os.path.join(LOG_DIR, fname)
            with open(path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            timestamp = lines[0][1:20] if lines else ""
            try:
                ts = datetime.strptime(timestamp, "%Y-%m-%d_%H-%M-%S")
                if now - ts <= timedelta(days=DAYS_BACK):
                    for line in lines:
                        if "Tag:" in line:
                            tag = line.replace("Tag:", "").strip().lower()
                            recent.append((tag, fname))
            except:
                continue
    return recent

def suggest():
    recent = recent_capsules()
    count = Counter([t[0] for t in recent])
    if not recent:
        print("📭 ไม่มี capsule ในช่วง 5 วันที่ผ่านมา")
        return
    print("🔎 Capsule ที่ควรหยิบมาใช้ต่อ:")
    for tag, _ in count.most_common(3):
        for t, fname in recent:
            if t == tag:
                print(f"• [{tag}] → {fname}")
                break

if __name__ == "__main__":
    suggest()
