
# reflex_persona_router.py
# Reflex Persona Router – กระจาย log ไปยัง Betty / Office / Jarvis

import os
from datetime import datetime

PERSONA_PATHS = {
    "betty": "Bedroom_Betty/logs",
    "office": "Office_Room/logs",
    "jarvis": "Jarvis_Lab/logs"
}

def write_capsule(persona, tag, note, trigger_type="manual"):
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    if persona not in PERSONA_PATHS:
        raise ValueError(f"❌ Persona '{persona}' ไม่ถูกต้อง")
    
    log_path = PERSONA_PATHS[persona]
    os.makedirs(log_path, exist_ok=True)
    
    filename = f"{log_path}/capsule_{trigger_type}_{tag}_{timestamp}.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"[{timestamp}]\nTrigger: {trigger_type}\nPersona: {persona}\nTag: {tag}\nNote: {note}\n")
    
    print(f"✅ Saved to {persona}: {filename}")

if __name__ == "__main__":
    # ทดสอบ: เขียนให้ทั้ง 3 persona
    write_capsule("betty", "hopeful", "Started new memory model.", "emotion")
    write_capsule("office", "error_handled", "Fixed bash unzip disaster.", "event")
    write_capsule("jarvis", "curious", "Running capsule AI classification test.", "emotion")
