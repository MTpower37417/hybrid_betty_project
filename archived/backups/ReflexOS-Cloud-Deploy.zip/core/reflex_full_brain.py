
# reflex_full_brain.py
# Reflex Brain Combo – ควบคุมทุกส่วน: Sync, Merge, Predict, Causal, React

import subprocess
import threading
import time

def run_sub(name, cmd):
    def target():
        print(f"▶️ เริ่ม {name}")
        subprocess.run(cmd, shell=True)
    t = threading.Thread(target=target)
    t.start()
    return t

if __name__ == "__main__":
    print("🧠 Full Reflex AI Brain Booting...\n")

    threads = [
        run_sub("Sync Engine", "python reflex_sync_engine.py"),
        run_sub("Merge Timeline", "python reflex_merge_timeline.py"),
        run_sub("Predictor", "python reflex_predictor.py"),
        run_sub("Causal Analyzer", "python reflex_causal.py"),
        run_sub("Autopilot", "python reflex_autopilot.py"),
        run_sub("Reactor", "python reflex_reactor.py")
    ]

    while True:
        time.sleep(10)
