# reflex_plan_flowchart.py
# แสดง flowchart แบบ simple จากแผน Reflex

steps = [
    "📥 รับ capsule: error_handled",
    "🔍 วิเคราะห์ root cause",
    "📊 ตรวจ log module",
    "🧠 Recall pattern เดิม",
    "🛠️ Patch / Fix",
    "📤 Log กลับเข้า Reflex"
]

print("📈 Reflex Flow Plan:")
for i, step in enumerate(steps, 1):
    print(f"{i}. {step}")
