
# reflex_sync_engine.py
# Reflex Sync Engine – กระจายความจำร่วมกันระหว่างบุคลิก AI

import os
import shutil

SOURCE_DIRS = {
    "betty": "Bedroom_Betty/logs",
    "jarvis": "Jarvis_Lab/logs",
    "office": "Office_Room/logs"
}

SYNC_FOLDER = "ReflexSystem_Sync"

def ensure_sync_folder():
    os.makedirs(SYNC_FOLDER, exist_ok=True)
    for persona in SOURCE_DIRS:
        os.makedirs(os.path.join(SYNC_FOLDER, persona), exist_ok=True)

def sync_capsules():
    ensure_sync_folder()
    count = 0
    for persona, path in SOURCE_DIRS.items():
        if not os.path.exists(path):
            continue
        for fname in os.listdir(path):
            if fname.startswith("capsule_") and fname.endswith(".txt"):
                src = os.path.join(path, fname)
                dest = os.path.join(SYNC_FOLDER, persona, fname)
                shutil.copy2(src, dest)
                count += 1
    print(f"✅ ซิงค์ capsule ข้ามบุคลิกสำเร็จทั้งหมด: {count} รายการ")
    print(f"📂 ดูผลลัพธ์ที่: {SYNC_FOLDER}/<persona>/")

if __name__ == "__main__":
    sync_capsules()
