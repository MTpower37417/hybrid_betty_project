
# reflex_speaker.py
# Reflex TTS Speaker – ให้ AI พูดด้วยเสียงจริง (Betty + Jarvis)

import pyttsx3
import sys

def speak(text, voice_type="betty"):
    engine = pyttsx3.init()
    voices = engine.getProperty("voices")

    if voice_type == "jarvis":
        engine.setProperty("voice", voices[-1].id)  # ใช้เสียงผู้ชาย
        engine.setProperty("rate", 180)
    else:
        engine.setProperty("voice", voices[0].id)  # ใช้เสียงผู้หญิง
        engine.setProperty("rate", 165)

    engine.say(text)
    engine.runAndWait()

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("📌 วิธีใช้: python reflex_speaker.py <betty|jarvis> <ข้อความ>")
        sys.exit(0)

    persona = sys.argv[1]
    sentence = " ".join(sys.argv[2:])
    speak(sentence, persona)
