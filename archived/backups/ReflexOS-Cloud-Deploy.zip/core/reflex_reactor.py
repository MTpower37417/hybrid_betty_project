
# reflex_reactor.py
# Reflex Reactor – ตอบกลับอัตโนมัติถ้าพบอารมณ์ที่ต้องจัดการ

import os
import time
from reflex_speaker import speak

WATCH_FOLDER = "Bedroom_Betty/logs"
SEEN = set()

RESPONSE_RULES = {
    "frustrated": "I noticed you're overwhelmed. Let's take a 5-minute break.",
    "sad": "It's okay to slow down. You don't have to do everything at once.",
    "curious": "Let's explore that idea further when you're ready.",
    "hopeful": "Hold onto that feeling. Progress is coming.",
    "happy": "I'm glad you're in a good space. Keep going!"
}

def check_and_respond():
    for fname in os.listdir(WATCH_FOLDER):
        if not fname.startswith("capsule_") or not fname.endswith(".txt"):
            continue
        fpath = os.path.join(WATCH_FOLDER, fname)
        if fpath in SEEN:
            continue
        SEEN.add(fpath)
        with open(fpath, "r", encoding="utf-8") as f:
            lines = f.readlines()
            for line in lines:
                if line.startswith("Tag:"):
                    tag = line.replace("Tag:", "").strip().lower()
                    if tag in RESPONSE_RULES:
                        response = RESPONSE_RULES[tag]
                        print(f"🧠 Reflex Response ({tag}): {response}")
                        speak(response, "betty")

def loop():
    print("🧠 Reflex Reactor Monitoring Betty...")
    while True:
        check_and_respond()
        time.sleep(3)

if __name__ == "__main__":
    loop()
