
# reflex_fusion_linker.py
# Reflex Fusion Engine: เชื่อมความทรงจำระหว่าง Betty และ Office

import os
from datetime import datetime

BETTY_LOG = "Bedroom_Betty/logs"
OFFICE_LOG = "Office_Room/logs"
FUSION_DIR = "ReflexSystem_Fusion"

def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)

def tag_crossover(tag):
    fusion_tags = {
        "frustrated": "error_handled",
        "hopeful": "brainstorm",
        "tired": "task_reset",
        "curious": "new_direction",
        "anxious": "clarify_goal"
    }
    return fusion_tags.get(tag.lower(), "context_sync")

def process_capsule(folder, persona):
    for fname in os.listdir(folder):
        if fname.startswith("capsule_") and fname.endswith(".txt"):
            fpath = os.path.join(folder, fname)
            with open(fpath, "r", encoding="utf-8") as f:
                lines = f.readlines()

            ts, tag, note = None, "unknown", ""
            for line in lines:
                if line.startswith("["):
                    ts = line[1:20]
                if "Tag:" in line:
                    tag = line.replace("Tag:", "").strip()
                if "Note:" in line:
                    note = line.replace("Note:", "").strip()

            if ts:
                new_tag = tag_crossover(tag)
                fusion_name = f"fusion_{persona}_{new_tag}_{ts}.txt"
                fusion_path = os.path.join(FUSION_DIR, fusion_name)

                with open(fusion_path, "w", encoding="utf-8") as out:
                    out.write(f"[{ts}]\n")
                    out.write(f"Source: {persona}\n")
                    out.write(f"Original Tag: {tag}\n")
                    out.write(f"Mapped Tag: {new_tag}\n")
                    out.write(f"Note: {note}\n")

def run_fusion():
    print("🔗 เชื่อมโยงอารมณ์ & ความจำระหว่าง Betty และ Office...")
    ensure_dir(FUSION_DIR)
    process_capsule(BETTY_LOG, "betty")
    process_capsule(OFFICE_LOG, "office")
    print(f"✅ สร้าง Fusion Capsule สำเร็จที่: {FUSION_DIR}/")

if __name__ == "__main__":
    run_fusion()
