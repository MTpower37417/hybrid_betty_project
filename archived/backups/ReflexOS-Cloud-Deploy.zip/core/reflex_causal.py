
# reflex_causal.py
# หาสาเหตุว่าอารมณ์ไหนเกิดจากอะไร (Causal Inference)

import os
from collections import defaultdict

LOG_DIRS = [
    "Bedroom_Betty/logs",
    "Jarvis_Lab/logs",
    "Office_Room/logs"
]

def extract_cause_from_note(note):
    note = note.lower()
    if "file" in note or "unzip" in note or "error" in note:
        return "System overload or I/O stress"
    if "missed" in note or "ignored" in note:
        return "Emotional neglect or misalignment"
    if "start" in note or "begin" in note:
        return "Change or initiation pressure"
    if "loop" in note or "again" in note:
        return "Repeating failure or inefficiency"
    return "Unknown / Internal cause"

def extract_tag_and_note(path):
    tag = "unknown"
    note = ""
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.startswith("Tag:"):
                tag = line.replace("Tag:", "").strip().lower()
            elif "Note:" in line:
                note = line.replace("Note:", "").strip()
    return tag, note

def analyze_causes():
    cause_map = defaultdict(list)
    for folder in LOG_DIRS:
        if not os.path.exists(folder):
            continue
        for fname in os.listdir(folder):
            if fname.startswith("capsule_") and fname.endswith(".txt"):
                fpath = os.path.join(folder, fname)
                tag, note = extract_tag_and_note(fpath)
                cause = extract_cause_from_note(note)
                cause_map[cause].append(tag)

    print("🔍 วิเคราะห์สาเหตุของอารมณ์:")
    for cause, tags in cause_map.items():
        tag_summary = ", ".join(tags)
        print(f"• {cause} → {tag_summary}")

if __name__ == "__main__":
    analyze_causes()
