# reflex_plan_assign_ai.py
# ส่งแผนให้ Betty และ Jarvis

agents = {
    "Betty": "emotion_monitor",
    "Jarvis": "logic_traceback"
}

print("📤 Assigning Reflex Plan to AI Units...")
for persona, task in agents.items():
    print(f"✅ {persona} รับ task: {task}")
