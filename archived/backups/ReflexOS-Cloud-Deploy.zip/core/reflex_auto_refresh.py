import os
import argparse

def refresh_latest_capsule(room, limit=1):
    base_path = os.path.dirname(__file__)
    folder = os.path.join(base_path, {
        "office": "Office_Room/cache",
        "betty": "Bedroom_Betty/cache"
    }[room])

    files = sorted(
        [f for f in os.listdir(folder) if f.endswith(".txt")],
        key=lambda x: os.path.getmtime(os.path.join(folder, x)),
        reverse=True
    )

    for f in files[:limit]:
        path = os.path.join(folder, f)
        print(f"🧠 Loading capsule: {f}\n")
        with open(path, "r", encoding="utf-8") as file:
            print(file.read())
            print("\n" + "-" * 40 + "\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--room', type=str, required=True, choices=["office", "betty"])
    parser.add_argument('--limit', type=int, default=1)
    args = parser.parse_args()

    refresh_latest_capsule(args.room, args.limit)