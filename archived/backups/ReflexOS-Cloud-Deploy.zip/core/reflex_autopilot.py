
# reflex_autopilot.py
# Reflex Autopilot – พูด capsule ใหม่โดยอัตโนมัติทันทีที่ตรวจพบ

import os
import time
from datetime import datetime
from reflex_speaker import speak

WATCH_FOLDERS = {
    "betty": "Bedroom_Betty/logs",
    "jarvis": "Jarvis_Lab/logs"
}

SEEN = set()

def get_new_capsules():
    new_capsules = []
    for persona, folder in WATCH_FOLDERS.items():
        if not os.path.exists(folder):
            continue
        for fname in os.listdir(folder):
            if fname.startswith("capsule_") and fname.endswith(".txt"):
                fpath = os.path.join(folder, fname)
                if fpath not in SEEN:
                    SEEN.add(fpath)
                    new_capsules.append((persona, fpath))
    return new_capsules

def read_and_speak(persona, path):
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
        for line in lines:
            if "Note:" in line:
                message = line.replace("Note:", "").strip()
                print(f"💬 [{persona}] {message}")
                speak(message, persona)
                break

def autopilot_loop():
    print("🧠 Reflex Autopilot Monitoring...")
    while True:
        new_files = get_new_capsules()
        for persona, path in new_files:
            read_and_speak(persona, path)
        time.sleep(3)

if __name__ == "__main__":
    autopilot_loop()
