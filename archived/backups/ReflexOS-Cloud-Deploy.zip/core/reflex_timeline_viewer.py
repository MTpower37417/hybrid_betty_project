
# reflex_timeline_viewer.py
# Reflex Timeline Viewer – แสดงความทรงจำเรียงตามเวลาแบบ GUI

import os
import tkinter as tk
from tkinter import ttk
from datetime import datetime

LOG_FOLDER = "Bedroom_Betty/logs"

def load_capsules():
    capsules = []
    if not os.path.exists(LOG_FOLDER):
        return capsules
    for fname in sorted(os.listdir(LOG_FOLDER)):
        if fname.endswith(".txt") and fname.startswith("capsule_"):
            fpath = os.path.join(LOG_FOLDER, fname)
            with open(fpath, "r", encoding="utf-8") as f:
                lines = f.readlines()
                timestamp = lines[0].strip() if lines else "Unknown"
                note = ""
                for line in lines:
                    if line.startswith("Note:"):
                        note = line.strip().replace("Note: ", "")
                capsules.append((timestamp, fname, note))
    return capsules

def show_timeline():
    window = tk.Tk()
    window.title("Reflex Timeline Viewer")
    window.geometry("700x500")

    tk.Label(window, text="🧠 Reflex Memory Timeline", font=("Arial", 16)).pack(pady=10)

    tree = ttk.Treeview(window, columns=("Timestamp", "Filename", "Note"), show="headings")
    tree.heading("Timestamp", text="Timestamp")
    tree.heading("Filename", text="Capsule File")
    tree.heading("Note", text="Note")
    tree.column("Timestamp", width=160)
    tree.column("Filename", width=280)
    tree.column("Note", width=240)

    for t, fname, note in load_capsules():
        tree.insert("", "end", values=(t, fname, note))
    tree.pack(expand=True, fill="both", padx=10, pady=10)

    window.mainloop()

if __name__ == "__main__":
    show_timeline()
