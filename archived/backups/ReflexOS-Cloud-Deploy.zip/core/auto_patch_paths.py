# auto_patch_paths.py
# ใช้สำหรับแก้ path ของ memory/config ใน ReflexOS/core/
import os

base_path = os.path.join(os.path.expanduser("~"), "Documents", "ReflexOS", "core")
replacements = {
    "memory_capsule.txt": "ReflexOS/memory/memory_capsule.txt",
    "office_config.json": "ReflexOS/core/office.reflex-config.json",
    "bedroom_config.json": "ReflexOS/core/bedroom.reflex-config.json",
}

for filename in os.listdir(base_path):
    if filename.endswith(".py") and filename != "auto_patch_paths.py":
        full_path = os.path.join(base_path, filename)
        with open(full_path, "r", encoding="utf-8") as f:
            content = f.read()
        modified = content
        for old, new in replacements.items():
            modified = modified.replace(old, new)
        if modified != content:
            with open(full_path, "w", encoding="utf-8") as f:
                f.write(modified)
            print(f"✅ Patched: {filename}")
