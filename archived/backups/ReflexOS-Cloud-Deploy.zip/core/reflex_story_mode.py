
# reflex_story_mode.py
# สร้าง Reflex Diary แบบ Story Mode (AI Narrative)

import os
from datetime import datetime

INPUT_FILE = "reflex_lifelog_diary.txt"
OUTPUT_FILE = "reflex_story_narrative.txt"

INTRO = [
    "It was a day unlike any other.",
    "As the clock ticked forward, emotions surfaced quietly.",
    "Every moment carried a fragment of meaning.",
    "And so the story of that day began..."
]

TAG_STYLE = {
    "hopeful": "with a hopeful heart",
    "sad": "feeling a shadow deep within",
    "frustrated": "clashing with the world around",
    "curious": "driven by a quiet wonder",
    "happy": "carrying a lightness in the air",
    "error": "with things breaking under pressure",
    "unzip_massive": "overwhelmed by digital noise",
    "unknown": "with an undefined mood"
}

def tag_to_phrase(tag):
    return TAG_STYLE.get(tag.lower(), TAG_STYLE["unknown"])

def convert_to_story():
    if not os.path.exists(INPUT_FILE):
        print("❌ ไม่พบไฟล์ reflex_lifelog_diary.txt")
        return

    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        lines = f.readlines()

    with open(OUTPUT_FILE, "w", encoding="utf-8") as out:
        current_day = ""
        for line in lines:
            if line.startswith("📅 วันที่:"):
                current_day = line.replace("📅 วันที่:", "").strip()
                out.write(f"📖 {random_intro()} — {current_day}\n\n")
            elif "⏰" in line:
                parts = line.strip().split("|")
                if len(parts) == 2:
                    time_part, content = parts
                    tag_note = content.strip().strip("[]")
                    if "]" in tag_note:
                        tag, note = tag_note.split("]", 1)
                        phrase = tag_to_phrase(tag)
                        out.write(f"At {time_part.strip()}, {phrase}, someone thought: “{note.strip()}.”\n")
            elif line.strip() == "":
                out.write("\n")

    print(f"📚 แปลงเป็น Story Mode แล้ว: {OUTPUT_FILE}")

def random_intro():
    import random
    return random.choice(INTRO)

if __name__ == "__main__":
    convert_to_story()
