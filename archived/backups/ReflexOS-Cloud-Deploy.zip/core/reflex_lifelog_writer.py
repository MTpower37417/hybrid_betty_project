
# reflex_lifelog_writer.py
# สร้างไดอารี่อัตโนมัติจาก capsule โดยเรียงตามเวลาและเขียนสรุปรายวัน

import os
from datetime import datetime
from collections import defaultdict

LOG_DIRS = [
    "Bedroom_Betty/logs",
    "Jarvis_Lab/logs",
    "Office_Room/logs"
]

OUTPUT_FILE = "reflex_lifelog_diary.txt"

def extract_data(path):
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    tag = "unknown"
    note = ""
    timestamp = None
    for line in lines:
        if line.startswith("["):
            try:
                timestamp = datetime.strptime(line[1:20], "%Y-%m-%d_%H-%M-%S")
            except:
                pass
        elif line.startswith("Tag:"):
            tag = line.replace("Tag:", "").strip()
        elif "Note:" in line:
            note = line.replace("Note:", "").strip()
    return timestamp, tag, note

def collect_diary():
    diary = defaultdict(list)
    for folder in LOG_DIRS:
        if not os.path.exists(folder):
            continue
        for fname in os.listdir(folder):
            if fname.startswith("capsule_") and fname.endswith(".txt"):
                fpath = os.path.join(folder, fname)
                ts, tag, note = extract_data(fpath)
                if ts:
                    date_key = ts.date().isoformat()
                    diary[date_key].append((ts.time(), tag, note))
    return diary

def write_diary():
    diary = collect_diary()
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        for date in sorted(diary):
            f.write(f"📅 วันที่: {date}\n")
            for t, tag, note in sorted(diary[date]):
                f.write(f"  ⏰ {t} | [{tag}] {note}\n")
            f.write("\n")
    print(f"📔 สร้าง Reflex Diary สำเร็จ: {OUTPUT_FILE}")

if __name__ == "__main__":
    write_diary()
