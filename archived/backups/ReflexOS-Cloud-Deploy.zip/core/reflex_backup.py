
# reflex_backup.py
# Backup memory capsule ทั้งระบบ (Reflex Type-3)

import os
from zipfile import ZipFile
from datetime import datetime

BACKUP_TARGETS = ["Bedroom_Betty", "reflex_summary.py", "reflex_report.py", "reflex_plot.py", "emotional_tracker.py"]
BACKUP_DIR = "backups"

def create_backup():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_name = f"{BACKUP_DIR}/reflex_backup_{timestamp}.zip"
    with ZipFile(zip_name, 'w') as zipf:
        for target in BACKUP_TARGETS:
            if os.path.isdir(target):
                for foldername, subfolders, filenames in os.walk(target):
                    for filename in filenames:
                        filepath = os.path.join(foldername, filename)
                        zipf.write(filepath)
            elif os.path.isfile(target):
                zipf.write(target)
    print(f"✅ Backup สำเร็จ: {zip_name}")

if __name__ == "__main__":
    create_backup()
