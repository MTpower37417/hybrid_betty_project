
# reflex_autorecall_office.py
# Auto Recall System – ดึง capsule ของ Office ที่เกี่ยวข้องกับคำค้น

import os

OFFICE_LOG = "Office_Room/logs"

def search_office_capsules(query):
    if not os.path.exists(OFFICE_LOG):
        print("❌ ไม่พบโฟลเดอร์ Office_Room/logs")
        return

    print(f"🔍 ค้นหา capsule ที่เกี่ยวข้องกับ: {query}\n")
    for fname in os.listdir(OFFICE_LOG):
        if fname.startswith("capsule_") and fname.endswith(".txt"):
            fpath = os.path.join(OFFICE_LOG, fname)
            with open(fpath, "r", encoding="utf-8") as f:
                content = f.read()
                if query.lower() in content.lower():
                    print(f"• {fname}")
                    preview = content.split("\n")[3] if len(content.split("\n")) > 3 else ""
                    print(f"  ↪️ {preview.strip()}\n")

if __name__ == "__main__":
    keyword = input("🧠 ป้อนคำค้นสำหรับ Recall: ").strip()
    if keyword:
        search_office_capsules(keyword)
    else:
        print("⚠️ โปรดป้อนคำก่อนเริ่มค้นหา")
