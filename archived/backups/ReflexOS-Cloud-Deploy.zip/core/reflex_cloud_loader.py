import os
import requests

def download_capsule_from_cloud(url, room="betty", base_dir=None):
    room_paths = {
        "office": "Office_Room/cache",
        "betty": "Bedroom_Betty/cache"
    }

    if room not in room_paths:
        raise ValueError("Room ต้องเป็น 'office' หรือ 'betty'")

    if not base_dir:
        base_dir = os.path.dirname(__file__)

    folder_path = os.path.join(base_dir, room_paths[room])
    os.makedirs(folder_path, exist_ok=True)

    filename = url.split("/")[-1].split("?")[0]
    save_path = os.path.join(folder_path, filename)

    try:
        response = requests.get(url)
        response.raise_for_status()
        with open(save_path, "wb") as f:
            f.write(response.content)
        print(f"✅ Capsule downloaded and saved to: {save_path}")
    except Exception as e:
        print(f"❌ Failed to download capsule: {e}")
        return None

    return save_path

# ตัวอย่างการใช้งาน
if __name__ == "__main__":
    # ตัวอย่าง URL (เปลี่ยนเป็นของจริงของ Boss)
    url = "https://example.com/betty_memory.txt"
    download_capsule_from_cloud(url, room="betty")