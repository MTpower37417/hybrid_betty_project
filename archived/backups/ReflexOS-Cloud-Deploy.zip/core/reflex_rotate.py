import os
import shutil

# กำหนดห้อง
room_paths = {
    "office": ("Office_Room/cache", "Office_Room/archive"),
    "betty": ("Bedroom_Betty/cache", "Bedroom_Betty/archive")
}

def rotate_memory(room, limit=3):
    cache_path, archive_path = room_paths[room]
    full_cache = os.path.join(os.path.dirname(__file__), cache_path)
    full_archive = os.path.join(os.path.dirname(__file__), archive_path)

    # เรียงไฟล์ตามเวลา (ล่าสุดอยู่ท้ายสุด)
    files = sorted([f for f in os.listdir(full_cache) if f.endswith(".txt")],
                   key=lambda x: os.path.getmtime(os.path.join(full_cache, x)))

    # ถ้าเกิน limit → ย้ายไฟล์เก่าไป archive
    if len(files) > limit:
        to_move = files[:len(files)-limit]
        for f in to_move:
            src = os.path.join(full_cache, f)
            dst = os.path.join(full_archive, f)
            shutil.move(src, dst)
            print(f"📦 Moved to archive: {f}")
    else:
        print("✅ Cache within limit. No files moved.")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Reflex FILO Memory Rotation")
    parser.add_argument('--room', type=str, required=True, choices=["office", "betty"], help="เลือกห้อง (office / betty)")
    parser.add_argument('--limit', type=int, default=3, help="จำนวนไฟล์สูงสุดที่เก็บไว้ใน cache")
    args = parser.parse_args()

    rotate_memory(args.room, args.limit)