
# reflex_jarvis_ai.py
# Reflex AI – Jarvis Personality: วิเคราะห์ capsule แล้วให้ insight

import os
import random
from datetime import datetime

JARVIS_LOGS = "Jarvis_Lab/logs"

def read_capsules():
    if not os.path.exists(JARVIS_LOGS):
        return []

    capsules = []
    for fname in sorted(os.listdir(JARVIS_LOGS), reverse=True):
        if not fname.startswith("capsule_"):
            continue
        fpath = os.path.join(JARVIS_LOGS, fname)
        with open(fpath, "r", encoding="utf-8") as f:
            content = f.read()
            capsules.append((fname, content))
    return capsules

def extract_insight(text):
    if "error" in text.lower():
        return "Detected technical failure. Recommend fallback command setup."
    elif "curious" in text.lower():
        return "Curiosity may indicate exploration window. Consider deploying test agents."
    elif "frustrated" in text.lower():
        return "Frustration patterns suggest suboptimal loop. Consider automating next decision."
    elif "unzip" in text.lower():
        return "Large file processing detected. Recommend archive filter mechanism."
    else:
        return "No major anomaly found. Reflex is stable."

def jarvis_respond():
    capsules = read_capsules()
    if not capsules:
        print("❌ Jarvis: No analytical memory found.")
        return

    print("🤖 Jarvis Memory Analyzer Booting...\n")
    for fname, content in capsules[:3]:
        print(f"📄 Log: {fname}")
        print(content.strip())
        insight = extract_insight(content)
        print(f"\n🧠 Jarvis Insight: {insight}")
        print("-" * 60)

if __name__ == "__main__":
    jarvis_respond()
