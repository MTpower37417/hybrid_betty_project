
# reflex_predictor.py
# Reflex Predictor – วิเคราะห์แนวโน้มอารมณ์จากความทรงจำย้อนหลัง

import os
from datetime import datetime
from collections import Counter

LOG_DIRS = [
    "Bedroom_Betty/logs",
    "Jarvis_Lab/logs",
    "Office_Room/logs"
]

def extract_tag_and_time(path):
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    tag = "unknown"
    timestamp = None
    for line in lines:
        if line.startswith("Tag:"):
            tag = line.replace("Tag:", "").strip().lower()
        elif line.startswith("["):
            try:
                timestamp = datetime.strptime(line[1:20], "%Y-%m-%d_%H-%M-%S")
            except:
                pass
    return tag, timestamp

def scan_trends():
    tags = []
    for folder in LOG_DIRS:
        if not os.path.exists(folder):
            continue
        for fname in os.listdir(folder):
            if fname.startswith("capsule_") and fname.endswith(".txt"):
                fpath = os.path.join(folder, fname)
                tag, _ = extract_tag_and_time(fpath)
                if tag:
                    tags.append(tag)

    count = Counter(tags)
    total = sum(count.values())
    print("🔎 แนวโน้มอารมณ์ล่าสุด:")
    for tag, freq in count.most_common():
        percent = (freq / total) * 100
        print(f"• {tag.upper():<12} = {freq} ({percent:.1f}%)")

    if count:
        trend = count.most_common(1)[0][0]
        print(f"📈 แนวโน้มเด่นตอนนี้: {trend.upper()}")

if __name__ == "__main__":
    scan_trends()
