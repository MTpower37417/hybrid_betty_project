
# reflex_capsule_replay.py
# Reflex Capsule Replay – อ่านความทรงจำย้อนหลังทีละ capsule

import os
import time
from datetime import datetime

LOG_FOLDER = "Bedroom_Betty/logs"

def load_capsules():
    capsules = []
    if not os.path.exists(LOG_FOLDER):
        return capsules
    for fname in sorted(os.listdir(LOG_FOLDER)):
        if fname.endswith(".txt") and fname.startswith("capsule_"):
            fpath = os.path.join(LOG_FOLDER, fname)
            with open(fpath, "r", encoding="utf-8") as f:
                content = f.read()
                capsules.append((fname, content))
    return capsules

def replay_capsules():
    capsules = load_capsules()
    if not capsules:
        print("❌ ไม่พบความทรงจำในระบบ")
        return

    print("🎥 เริ่ม Replay ความทรงจำ...\n")
    for fname, content in capsules:
        print(f"🧠 {fname}")
        print("-" * 60)
        print(content.strip())
        print("-" * 60)
        time.sleep(1.5)
        print()

if __name__ == "__main__":
    replay_capsules()
