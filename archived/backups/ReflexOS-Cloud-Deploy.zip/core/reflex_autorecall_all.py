
# reflex_autorecall_all.py
# Auto Recall ทุกห้อง: ค้นคำใน capsule ของ Betty + Office พร้อมกัน

import os

ROOMS = {
    "Betty": "Bedroom_Betty/logs",
    "Office": "Office_Room/logs"
}

def search_all_capsules(query):
    print(f"🔍 ค้นหา capsule ที่เกี่ยวข้องกับ: {query}\n")
    for room, folder in ROOMS.items():
        if not os.path.exists(folder):
            continue
        found = False
        for fname in os.listdir(folder):
            if fname.startswith("capsule_") and fname.endswith(".txt"):
                fpath = os.path.join(folder, fname)
                with open(fpath, "r", encoding="utf-8") as f:
                    content = f.read()
                    if query.lower() in content.lower():
                        print(f"🏷️ {room}: {fname}")
                        preview = content.split("\n")[3] if len(content.split("\n")) > 3 else ""
                        print(f"  ↪️ {preview.strip()}\n")
                        found = True
        if not found:
            print(f"📭 {room}: ไม่พบผลลัพธ์\n")

if __name__ == "__main__":
    keyword = input("🧠 ป้อนคำค้นสำหรับ Recall (ทุกห้อง): ").strip()
    if keyword:
        search_all_capsules(keyword)
    else:
        print("⚠️ โปรดป้อนคำก่อนเริ่มค้นหา")
