
# reflex_story_export_html.py
# แปลง reflex_story_narrative.txt เป็นไฟล์ HTML พร้อมจัดรูปแบบอ่านง่าย

import os

INPUT_FILE = "reflex_story_narrative.txt"
OUTPUT_FILE = "reflex_story_narrative.html"

def export_html():
    if not os.path.exists(INPUT_FILE):
        print("❌ ไม่พบไฟล์ story narrative")
        return

    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        lines = f.readlines()

    html = [
        "<html><head><meta charset='utf-8'><title>Reflex Story</title>",
        "<style>body{font-family:sans-serif;line-height:1.7;background:#f4f4f4;padding:40px;color:#333;}h1{color:#444;}p{margin-bottom:1em;}</style>",
        "</head><body>",
        "<h1>🧠 Reflex Story Narrative</h1><hr>"
    ]

    for line in lines:
        if line.startswith("📖"):
            html.append(f"<h2>{line.strip()}</h2>")
        elif line.strip() == "":
            html.append("<br>")
        else:
            html.append(f"<p>{line.strip()}</p>")

    html.append("</body></html>")

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(html))

    print(f"✅ Export สำเร็จ: {OUTPUT_FILE}")

if __name__ == "__main__":
    export_html()
