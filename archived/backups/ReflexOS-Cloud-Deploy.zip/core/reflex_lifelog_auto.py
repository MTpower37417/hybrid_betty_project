
# reflex_lifelog_auto.py
# สร้างไดอารี่ Reflex Capsule แบบอัตโนมัติทุกวัน

import os
from datetime import datetime

BASE_DIR = "Office_Room/logs"
now = datetime.now()
timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")

content = f"""📅 Reflex Daily Log – {now.strftime('%Y-%m-%d')}
สถานะระบบ: ONLINE
สรุป: วันนี้มีการทำงานร่วมกับ Reflex Capsule หลายชุด
คำสั่งล่าสุด: auto trigger, smart planner, GUI deploy, capsule recall
สถานะอารมณ์: ⚙️ productive + 💬 reflective
หมายเหตุ: Reflex พร้อมใช้งานในโหมด hybrid-autopilot แล้ว
"""

filename = os.path.join(BASE_DIR, f"lifelog_{timestamp}.txt")
if not os.path.exists(BASE_DIR):
    os.makedirs(BASE_DIR)

with open(filename, "w", encoding="utf-8") as f:
    f.write(content)

print(f"✅ บันทึก lifelog อัตโนมัติที่: {filename}")
