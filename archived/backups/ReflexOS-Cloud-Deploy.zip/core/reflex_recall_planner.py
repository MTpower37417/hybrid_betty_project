
# reflex_recall_planner.py
# สร้างแผนจาก capsule tag โดยใช้ logic ที่เคยใช้ได้ผล

import os

CAPSULE_DIR = "Office_Room/logs"
OUTPUT_FILE = "reflex_plan_from_capsule.txt"

TAG_PLAN_MAP = {
    "error_handled": [
        "✅ วิเคราะห์ root cause ทันทีที่พบ error",
        "✅ ตรวจ log ที่เกี่ยวข้อง (timestamp, module)",
        "✅ ใช้คำสั่ง 'reflex_autorecall_office.py' เพื่อดู pattern error เดิม",
        "✅ สร้าง patch / fix script แล้ว log กลับเข้า Reflex"
    ],
    "brainstorm": [
        "🧠 เปิด session 'creative boost'",
        "🗂️ ดึงไอเดียเก่าจาก capsule ที่เกี่ยวข้อง",
        "✅ สร้าง note ใหม่ทุก 20 นาที",
        "📤 ส่งเข้า Betty เพื่อประเมินอารมณ์พร้อมกัน"
    ],
    "trigger": [
        "⚙️ สร้าง sensor หรือ watcher event",
        "🧠 ผูกเข้ากับ reflex_hybrid_trigger.py",
        "✅ สั่งให้ reflex_plot หรือ reflex_reactor ทำงานทันทีเมื่อ trigger"
    ]
}

def find_latest_tag():
    latest = None
    latest_tag = None
    for fname in os.listdir(CAPSULE_DIR):
        if fname.startswith("capsule_") and fname.endswith(".txt"):
            path = os.path.join(CAPSULE_DIR, fname)
            with open(path, "r", encoding="utf-8") as f:
                lines = f.readlines()
                if lines and "Tag:" in "".join(lines):
                    for line in lines:
                        if line.startswith("Tag:"):
                            tag = line.replace("Tag:", "").strip().lower()
                            latest = fname
                            latest_tag = tag
                            break
    return latest, latest_tag

def create_plan():
    capsule, tag = find_latest_tag()
    if not tag:
        print("❌ ไม่พบ capsule ที่มี tag เพื่อแปลงเป็นแผนงาน")
        return

    steps = TAG_PLAN_MAP.get(tag, [])
    if not steps:
        print(f"⚠️ ยังไม่มีแผนอัตโนมัติสำหรับ tag: {tag}")
        return

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(f"📄 Reflex Plan (tag: {tag})\nจาก capsule: {capsule}\n\n")
        for step in steps:
            f.write(f"{step}\n")

    print(f"✅ สร้างแผนงานสำเร็จ: {OUTPUT_FILE}")

if __name__ == "__main__":
    create_plan()
