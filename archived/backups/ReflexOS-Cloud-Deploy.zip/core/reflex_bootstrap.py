import os
from datetime import datetime

def get_latest_capsule_path(room):
    room_paths = {
        "office": "Office_Room/cache",
        "betty": "Bedroom_Betty/cache"
    }

    base_path = os.path.dirname(__file__)
    folder = os.path.join(base_path, room_paths[room])
    files = sorted(
        [f for f in os.listdir(folder) if f.endswith(".txt")],
        key=lambda x: os.path.getmtime(os.path.join(folder, x)),
        reverse=True
    )
    if not files:
        return None
    return os.path.join(folder, files[0])

def reflex_bootstrap(room="betty"):
    path = get_latest_capsule_path(room)
    if not path:
        print("⚠️ No capsule found.")
        return

    print(f"🧠 Reflex ON — Loading memory capsule for {room.upper()}")
    print(f"📄 File: {os.path.basename(path)}\n")
    with open(path, "r", encoding="utf-8") as f:
        print(f.read())
        print("\n" + "-" * 40 + "\n")

if __name__ == "__main__":
    reflex_bootstrap("betty")