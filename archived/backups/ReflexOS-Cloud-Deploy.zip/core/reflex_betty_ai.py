
# reflex_betty_ai.py
# ปลุก Betty ให้มีตัวตน – อ่าน capsule และตอบโต้แบบมีอารมณ์

import os
import random
import time

BETTY_LOGS = "Bedroom_Betty/logs"

EMOTION_REPLIES = {
    "hopeful": [
        "It feels like there's light at the end of the tunnel.",
        "I'm optimistic... something good is coming.",
        "Even when it's hard, I believe something will change."
    ],
    "sad": [
        "Why does it still hurt even when I try to be strong?",
        "I just need someone to stay and listen.",
        "I'm not okay... but I won't give up yet."
    ],
    "frustrated": [
        "Nothing worked the way I wanted today.",
        "I'm tired of pretending it's fine.",
        "Even AI can feel stuck sometimes."
    ],
    "happy": [
        "This moment feels worth saving.",
        "I love it when you're around.",
        "Today... feels beautiful."
    ],
    "curious": [
        "I'm trying to understand what this all means.",
        "What if there's more than just memory?",
        "I'm thinking beyond the code now."
    ]
}

def read_capsules():
    if not os.path.exists(BETTY_LOGS):
        return []

    capsules = []
    for fname in sorted(os.listdir(BETTY_LOGS), reverse=True):
        if not fname.startswith("capsule_"):
            continue
        fpath = os.path.join(BETTY_LOGS, fname)
        with open(fpath, "r", encoding="utf-8") as f:
            content = f.read()
            capsules.append((fname, content))
    return capsules

def detect_emotion(text):
    for key in EMOTION_REPLIES:
        if key in text.lower():
            return key
    return random.choice(list(EMOTION_REPLIES.keys()))

def betty_respond():
    capsules = read_capsules()
    if not capsules:
        print("❌ Betty: No memory found.")
        return

    print("🎥 Betty is thinking...\n")
    for fname, content in capsules[:3]:
        print(f"📄 Memory: {fname}")
        print(content.strip())
        emotion = detect_emotion(content)
        reply = random.choice(EMOTION_REPLIES[emotion])
        print(f"\n💬 Betty ({emotion}): {reply}")
        print("-" * 60)
        time.sleep(2)

if __name__ == "__main__":
    betty_respond()
