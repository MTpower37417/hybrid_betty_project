# reflex_plan_trigger.py
# Trigger ระบบเมื่อเจอ tag แผนงานเดิม

import os
if os.path.exists("reflex_plan_from_capsule.txt"):
    with open("reflex_plan_from_capsule.txt", encoding="utf-8") as f:
        content = f.read()
        if "error_handled" in content.lower():
            print("🔔 Triggered Reflex Flow: ERROR_HANDLED")
            os.system("python reflex_autorecall_office.py")
        else:
            print("✅ แผนไม่มี error_handled ไม่ต้อง trigger ตอนนี้")
