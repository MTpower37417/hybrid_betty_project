
# reflex_gui_hybrid_launcher.py
# Reflex GUI Launcher แบบ Hybrid (Emotion + Event Trigger)

import tkinter as tk
from tkinter import messagebox
import subprocess
import os
from datetime import datetime

def run_command(cmd, desc):
    try:
        subprocess.run(cmd, shell=True, check=True)
        messagebox.showinfo("Success", f"{desc} completed successfully.")
    except subprocess.CalledProcessError:
        messagebox.showerror("Error", f"{desc} failed. Please check logs.")

def log_capsule(trigger_type, tag, note):
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_dir = "Bedroom_Betty/logs"
    os.makedirs(log_dir, exist_ok=True)
    filename = f"{log_dir}/capsule_{trigger_type}_{tag}_{timestamp}.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"[{timestamp}]\nTrigger: {trigger_type}\nTag: {tag}\nNote: {note}\n")
    messagebox.showinfo("Saved", f"{trigger_type.capitalize()} Capsule Saved:\n{filename}")

def launch_gui():
    window = tk.Tk()
    window.title("Reflex Hybrid Launcher")
    window.geometry("450x500")

    tk.Label(window, text="🧠 Reflex Hybrid System", font=("Arial", 16)).pack(pady=10)

    # Emotion Trigger Section
    tk.Label(window, text="Emotion Trigger", font=("Arial", 12, "bold")).pack(pady=5)
    emotion_entry = tk.Entry(window, width=40)
    emotion_entry.insert(0, "frustrated")
    emotion_entry.pack(pady=2)
    emotion_note = tk.Entry(window, width=40)
    emotion_note.insert(0, "Example: Missed AI trigger.")
    emotion_note.pack(pady=2)
    tk.Button(window, text="Log Emotion", width=30,
              command=lambda: log_capsule("emotion", emotion_entry.get(), emotion_note.get())).pack(pady=5)

    # Event Trigger Section
    tk.Label(window, text="Event Trigger", font=("Arial", 12, "bold")).pack(pady=10)
    event_entry = tk.Entry(window, width=40)
    event_entry.insert(0, "unzip_massive")
    event_entry.pack(pady=2)
    event_note = tk.Entry(window, width=40)
    event_note.insert(0, "Example: Sent 3000 files to AI.")
    event_note.pack(pady=2)
    tk.Button(window, text="Log System Event", width=30,
              command=lambda: log_capsule("event", event_entry.get(), event_note.get())).pack(pady=5)

    # Utility Buttons
    tk.Label(window, text="Other Reflex Functions", font=("Arial", 12, "bold")).pack(pady=15)
    tk.Button(window, text="Summary Report", width=30,
              command=lambda: run_command("python reflex_summary.py", "Summary Report")).pack(pady=3)
    tk.Button(window, text="Export CSV", width=30,
              command=lambda: run_command("python reflex_report.py", "Export CSV")).pack(pady=3)
    tk.Button(window, text="Generate Plot", width=30,
              command=lambda: run_command("python reflex_plot.py", "Generate Plot")).pack(pady=3)
    tk.Button(window, text="Backup System", width=30,
              command=lambda: run_command("bash reflex_auto_backup.sh", "Backup")).pack(pady=3)
    tk.Button(window, text="Restore Latest Backup", width=30,
              command=lambda: run_command("bash reflex_auto_restore.sh", "Restore")).pack(pady=3)

    tk.Button(window, text="Exit", width=30, command=window.destroy).pack(pady=15)
    window.mainloop()

if __name__ == "__main__":
    os.chdir(os.path.dirname(__file__))
    launch_gui()
