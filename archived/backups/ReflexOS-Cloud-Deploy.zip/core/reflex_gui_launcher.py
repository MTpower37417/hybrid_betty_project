
# reflex_gui_launcher.py
# Reflex Type-3 GUI Launcher (fixed string quoting)

import tkinter as tk
from tkinter import messagebox
import subprocess
import os

def run_command(cmd, desc):
    try:
        subprocess.run(cmd, shell=True, check=True)
        messagebox.showinfo("Success", f"{desc} completed successfully.")
    except subprocess.CalledProcessError:
        messagebox.showerror("Error", f"{desc} failed. Please check logs.")

def launch_gui():
    window = tk.Tk()
    window.title("Reflex Capsule Launcher")
    window.geometry("400x400")

    tk.Label(window, text="🧠 Reflex Capsule System", font=("Arial", 16)).pack(pady=10)

    tk.Button(window, text="Log Emotion", width=30,
              command=lambda: run_command("python emotional_tracker.py happy \"GUI launched\"", "Log Emotion")).pack(pady=5)

    tk.Button(window, text="Summary Report", width=30,
              command=lambda: run_command("python reflex_summary.py", "Summary Report")).pack(pady=5)

    tk.Button(window, text="Export CSV", width=30,
              command=lambda: run_command("python reflex_report.py", "Export CSV")).pack(pady=5)

    tk.Button(window, text="Generate Plot", width=30,
              command=lambda: run_command("python reflex_plot.py", "Generate Plot")).pack(pady=5)

    tk.Button(window, text="Backup System", width=30,
              command=lambda: run_command("bash reflex_auto_backup.sh", "Backup")).pack(pady=5)

    tk.Button(window, text="Restore Latest Backup", width=30,
              command=lambda: run_command("bash reflex_auto_restore.sh", "Restore")).pack(pady=5)

    tk.Button(window, text="Exit", width=30, command=window.destroy).pack(pady=20)

    window.mainloop()

if __name__ == "__main__":
    os.chdir(os.path.dirname(__file__))
    launch_gui()
