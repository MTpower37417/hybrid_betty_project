
import requests
import os

def download_from_direct_link(url, output_path):
    response = requests.get(url)
    if response.status_code == 200:
        with open(output_path, "wb") as f:
            f.write(response.content)
        print(f"✅ File downloaded to {output_path}")
    else:
        print(f"❌ Failed to download file. Status code: {response.status_code}")

if __name__ == "__main__":
    import json
    with open("capsule_link_config.json", "r") as f:
        config = json.load(f)

    url = config.get("direct_download_url")
    output = config.get("save_as", "reflex_capsule_memory.txt")

    if url:
        download_from_direct_link(url, output)
    else:
        print("❌ No URL found in config file.")
