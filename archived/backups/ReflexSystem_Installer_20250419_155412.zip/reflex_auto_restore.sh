
#!/bin/bash
# reflex_auto_restore.sh
# กู้คืนไฟล์ backup ZIP ล่าสุดจากโฟลเดอร์ backups/ (Reflex Type-3)

cd ~/Documents/ReflexSystem

latest_zip=$(ls -t backups/*.zip 2>/dev/null | head -n 1)

if [ -z "$latest_zip" ]; then
    echo "❌ ไม่พบไฟล์ backup ใน backups/"
    exit 1
fi

echo "🔄 กำลังกู้คืน: $latest_zip"
python reflex_restore.py "$latest_zip"
