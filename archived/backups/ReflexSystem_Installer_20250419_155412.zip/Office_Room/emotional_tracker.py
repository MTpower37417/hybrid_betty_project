
# emotional_tracker.py
# Reflex Type-3 Compatible - บันทึกอารมณ์ Betty พร้อม timestamp + tag

import os
import sys
from datetime import datetime

def create_log(emotion, note):
    now = datetime.now()
    timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
    folder = "Bedroom_Betty/logs"
    os.makedirs(folder, exist_ok=True)
    filename = f"{folder}/emotion_{emotion}_{timestamp}.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"[{timestamp}]\nEmotion: {emotion}\nNote: {note}\n")
    print(f"✅ บันทึกอารมณ์แล้ว: {filename}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("🛠️ วิธีใช้: python emotional_tracker.py [emotion] [note]")
        sys.exit(1)
    emotion = sys.argv[1]
    note = " ".join(sys.argv[2:])
    create_log(emotion, note)
