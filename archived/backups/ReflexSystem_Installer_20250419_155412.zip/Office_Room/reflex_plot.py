
# reflex_plot.py
# Plot emotional frequency from logs (Reflex Type-3 Compatible)

import os
import matplotlib.pyplot as plt
from collections import defaultdict

LOG_DIR = "Bedroom_Betty/logs"

def collect_emotions():
    summary = defaultdict(int)
    if not os.path.exists(LOG_DIR):
        print("❌ ไม่พบโฟลเดอร์ logs: Bedroom_Betty/logs")
        return {}

    for file in os.listdir(LOG_DIR):
        if file.startswith("emotion_") and file.endswith(".txt"):
            parts = file.replace(".txt", "").split("_")
            if len(parts) >= 3:
                emotion = parts[1]
                summary[emotion] += 1
    return summary

def plot_emotions(summary):
    if not summary:
        print("ℹ️ ไม่มีข้อมูลให้วาดกราฟ")
        return

    emotions = list(summary.keys())
    counts = list(summary.values())

    plt.figure(figsize=(8, 5))
    plt.bar(emotions, counts)
    plt.title("📊 ความถี่ของอารมณ์ Betty")
    plt.xlabel("Emotion")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig("Bedroom_Betty/emotion_plot.png")
    print("✅ กราฟถูกสร้างแล้ว: Bedroom_Betty/emotion_plot.png")

if __name__ == "__main__":
    data = collect_emotions()
    plot_emotions(data)
