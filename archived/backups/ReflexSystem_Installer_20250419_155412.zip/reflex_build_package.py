
# reflex_build_package.py
# สร้าง ZIP Installer สำหรับ Reflex System (ใช้ Python แทน shell zip)

import os
from zipfile import ZipFile
from datetime import datetime

PACKAGE_NAME = f"ReflexSystem_Installer_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
TARGETS = ["Bedroom_Betty", "Office_Room", "backups"]
EXTRA_FILES = [f for f in os.listdir() if f.endswith(".py") or f.endswith(".sh")]

with ZipFile(PACKAGE_NAME, 'w') as zipf:
    for target in TARGETS:
        if os.path.exists(target):
            for root, dirs, files in os.walk(target):
                for file in files:
                    full_path = os.path.join(root, file)
                    zipf.write(full_path)
    for file in EXTRA_FILES:
        zipf.write(file)

print(f"✅ Reflex Package Created: {PACKAGE_NAME}")
