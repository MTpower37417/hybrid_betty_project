
#!/bin/bash
# reflex_auto_backup.sh
# สร้าง ZIP สำรองข้อมูล Reflex Capsule อัตโนมัติ (Reflex Type-3)

cd ~/Documents/ReflexSystem

echo "🔁 เริ่มสำรองข้อมูล Reflex..."

python reflex_backup.py

echo "✅ เสร็จสิ้นการสำรองข้อมูล"
