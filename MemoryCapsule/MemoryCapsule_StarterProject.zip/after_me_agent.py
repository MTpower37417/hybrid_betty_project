# Python agent that replies based on memory + identity capsule
